__version__ = "0.0.8.1"
__name__ = "PMMP"

from PMMP.functions import *
from PMMP.probability import *
from PMMP.numbers import *
