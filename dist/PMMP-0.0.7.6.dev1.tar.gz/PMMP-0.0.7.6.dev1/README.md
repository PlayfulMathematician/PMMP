# PMMP
> NOTE: PMMP is a math library.

## Table of Contents
 - [Installation](#Installation)
 - [Docs](#Usage)


# Installation 
## MacOS
`$ pip3 install PMMP`

# Docs
