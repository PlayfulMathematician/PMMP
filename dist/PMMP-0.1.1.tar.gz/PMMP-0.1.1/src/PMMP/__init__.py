__version__ = "0.1.1"
__name__ = "PMMP"

from PMMP.numbers import *
from PMMP.functions import *
from PMMP.probability import *


