# PMMP (Playful Mathematicians Math Playground)
> NOTE: PMMP is a math library.

## Table of Contents
 - [Installation](#Installation)
 - [Docs](#Docs)
 - 


# Installation 
## MacOS
```bash
$ pip3 install PMMP
```

# Docs
