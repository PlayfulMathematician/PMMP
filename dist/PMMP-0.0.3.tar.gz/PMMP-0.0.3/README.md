# PMMP
PMMP is a basic math library